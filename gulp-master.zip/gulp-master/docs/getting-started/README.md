# Getting Started

1. [Quick Start](1-quick-start.md)
2. [JavaScript and Gulpfiles](2-javascript-and-gulpfiles.md)
3. [Creating Tasks](3-creating-tasks.md)
4. [Async Completion](4-async-completion.md)
5. [Working with Files](5-working-with-files.md)
6. [Explaining Globs](6-explaining-globs.md)
7. [Using Plugins](7-using-plugins.md)
8. [Watching Files](8-watching-files.md)
