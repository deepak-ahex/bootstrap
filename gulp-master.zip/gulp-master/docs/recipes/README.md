<!-- front-matter
id: recipes
title: Recipes
hide_title: true
sidebar_label: Recipes
-->

# Recipes

* [Automate release workflow](automate-release-workflow.md)
* [Combining streams to handle errors](combining-streams-to-handle-errors.md)
* [Delete files and folders](delete-files-folder.md)
* [Fast browserify builds with watchify](fast-browserify-builds-with-watchify.md)
* [Incremental rebuilding, including operating on full file sets](incremental-builds-with-concatenate.md)
* [Make stream from buffer (memory contents)](make-stream-from-buffer.md)
* [Mocha test-runner with gulp](mocha-test-runner-with-gulp.md)
* [Only pass through changed files](only-pass-through-changed-files.md)
* [Pass parameters from the command line](pass-arguments-from-cli.md)
* [Rebuild only files that change](rebuild-only-files-that-change.md)
* [Generating a file per folder](running-task-steps-per-folder.md)
* [Running tasks in series](running-tasks-in-series.md)
* [Server with live-reloading and CSS injection](server-with-livereload-and-css-injection.md)
* [Sharing streams with stream factories](sharing-streams-with-stream-factories.md)
* [Specifying a new cwd (current working directory)](specifying-a-cwd.md)
* [Split tasks across multiple files](split-tasks-across-multiple-files.md)
* [Using external config file](using-external-config-file.md)
* [Using multiple sources in one task](using-multiple-sources-in-one-task.md)
* [Browserify + Uglify with sourcemaps](browserify-uglify-sourcemap.md)
* [Browserify + Globs](browserify-with-globs.md)
* [Browserify + Globs (multiple destination)](browserify-multiple-destination.md)
* [Output both a minified and non-minified version](minified-and-non-minified.md)
* [Templating with Swig and YAML front-matter](templating-with-swig-and-yaml-front-matter.md)
* [Run Grunt Tasks from Gulp](run-grunt-tasks-from-gulp.md)
* [Exports as tasks](exports-as-tasks.md)
* [Rollup with rollup-stream](rollup-with-rollup-stream.md)
* [Run gulp task via cron job](cron-task.md)
* [Running shell commands](running-shell-commands.md)
